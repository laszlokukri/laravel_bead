@extends('layouts.base')

@section('title', 'Kezdőlap')

@section('main-content')

    <div class="mx-auto" style="max-width: 75rem">

        @auth
            @if (Auth::user()->is_admin == 1)
                <a href="{{ route('newmovie') }}" class="btn btn-primary m-3">Új film</a> <br>
            @endif
        @endauth

    @foreach ($movies as $movie)


        <div class="card text-center d-inline-block" style="width: 12rem; margin: 1rem;">
            <a href="{{ route('movie') }}?id={{$movie->id}}" class="text-decoration-none text-reset">
            <img src="{{ asset('posters/' . $movie->image) }}" alt="A filmhez nem tartozik kép" style="height: 18rem;" class="card-img-top">
            <div class="card-body">
            <h5 class="card-title @if ($movie->trashed())
                                    text-danger
                                  @endif ">{{$movie->title}}</h5>
            <p class="card-text">@php
                                    $rtg = 0;
                                    $cnt = 0;
                                    foreach ($ratings as $rating) {
                                        if ($movie->id == $rating->movie_id) {
                                            $rtg += $rating->rating;
                                            $cnt += 1;
                                        }
                                    }
                                    if ($cnt != 0) {
                                        echo $rtg/$cnt;
                                    }else{
                                        echo '0';
                                    }

                                @endphp/5</p>
            </div>
            </a>
        </div>

    @endforeach

    <div class="container mx-auto" style="max-width: 15rem;">
        {{ $movies->links() }}
    </div>


    </div>

@endsection
