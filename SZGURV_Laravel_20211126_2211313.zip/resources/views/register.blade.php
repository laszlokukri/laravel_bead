@extends('layouts.base')

@section('title', 'Regisztráció')
