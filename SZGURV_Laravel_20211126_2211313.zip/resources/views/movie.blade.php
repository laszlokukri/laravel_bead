@extends('layouts.base')

@section('title', 'Film leírása')

@php
    $title = '';
    $desc = '';
    $img = '';
    $deleted = false;
    //$rtg_en = false;

    foreach($movies as $movie){
        if ($movie->id == $id) {
            $title = $movie->title;
            $director = $movie->director;
            $year = $movie->year;
            $desc = $movie->description;
            $img = $movie->image;
            $rtg_en = $movie->ratings_enabled;
            if ($movie->trashed()) {
                $deleted = true;
            }
        }
    }

    $rtg = 0;
    $cnt = 0;
    foreach ($ratings as $rating) {
        if ($id == $rating->movie_id) {
            $rtg += $rating->rating;
            $cnt += 1;
        }
    }
    if ($cnt != 0) {
        $rtg = $rtg/$cnt;
    }else{
        $rtg = '0';
    }
@endphp

@section('main-content')

    <div class="container mx-auto" style="max-width: 85rem">

        @if (session('alert'))
            <div class="alert alert-success m-3">
                {{ session('alert') }}
            </div>
        @endif

        <p class="h1 d-inline-block" style="margin-top: 5rem;">{{ $title }}</p><p class="h4 d-inline-block mx-3">( {{ $year }} )</p>

        <img src="{{ asset('posters/' . $img) }}" alt="A filmhez nem tartozik kép" class="rounded float-end d-inline-block" style="max-height: 15rem; margin : 5rem;">
        <p class="h5">Rendező: {{ $director }}</p>
        <p class="">{{ $desc }}</p>
        <p><b>Pontszám:</b> {{ $rtg }}/5</p>

        <br><br>

        @auth()
            @if ($rtg_en == 'true')
                <form action=" {{ route('movie') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="rating" class="form-label"><b>Értékelés(1-5):</b></label>
                        <input type="text" name="rating" class="form-control" id="rating" style="max-width: 5rem;">
                    </div>
                    <div class="mb-3">
                        <label for="comment" class="form-label"><b>Komment:</b></label>
                        <textarea class="form-control" name="comment" id="comment" rows="3" style="max-width: 20rem;"></textarea>
                    </div>
                    <input type="hidden" name="movie_id" value="{{ $id }}">
                    <button type="submit" class="btn btn-primary">Értékelés</button>
                </form>
            @else
                <p>A film értékelése le van tiltva!</p>
            @endif

            @if (Auth::user()->is_admin == 1)
                <a href="{{ URL::to('deleterating/'.$id) }}" class="btn btn-primary mt-3 me-3">Értékelések törlése</a>
                <a href="{{ route('modmovie') }}?id={{$id}}" class="btn btn-primary mt-3 me-3">Módosítás</a>
                @if ($deleted)
                    <a href="{{ URL::to('movie/restoremovie/'.$id) }}" class="btn btn-primary mt-3">Visszaállítás</a> <br>
                @else
                    <a href="{{ URL::to('movie/deletemovie/'.$id) }}" class="btn btn-primary mt-3">Film törlése</a> <br>
                @endif
            @endif
        @endauth

        <div class="container text-center h4" style="margin-top: 3rem; margin-bottom: 3rem;">Értékelések:</div>

        @foreach ($ratings->reverse() as $rating)
            @if ($rating->movie_id == $id)

                <div class="card" style="margin-bottom:1rem;">
                    <div class="card-body">
                    <h5 class="card-title">@php
                                            foreach ($users as $user) {
                                                if($user->id == $rating->user_id){
                                                    echo $user->name;
                                                }
                                            }

                                            @endphp</h5>
                    <h6 class="card-subtitle mb-2 text-muted">{{ $rating->rating }}/5</h6>
                    <p class="card-text">{{ $rating->comment }}</p>
                    </div>
                </div>

            @endif
        @endforeach



    </div>

@endsection
