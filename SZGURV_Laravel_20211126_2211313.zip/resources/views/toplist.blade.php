@extends('layouts.base')

@section('title', 'Toplista')

@section('main-content')

<div class="mx-auto" style="max-width: 60rem;">

@php
    $count = count($rts);
    for($i=0; $i<6; $i++){
        $mx=0;
        $mx_id=0;
        for($j=1; $j < $count; $j++){
            if($rts[$j] >= $mx){
                $mx=$rts[$j];
                $mx_id=$j;
            }
        }
        $rts[$mx_id] = -1;

        foreach ($movies as $movie) {
            if($movie->id == $mx_id){
                echo '
                <div class="card mb-3" style="max-height: 10rem; max-width: auto;">
                <div class="row g-0">
                <div class="col-md-4" style="max-width: 10rem;">
                <img src="posters/' . $movie->image . '" class="img-fluid rounded-start" style="max-width: 10rem; max-height: 10rem;">
                </div>
                <div class="col-md-8">
                <div class="card-body">
                <h5 class="card-title"> ' . $movie->title . '</h5>
                <p class="card-text">' . $mx . '/5</p>
                </div>
                </div>
                </div>
                </div>
                ';
            }
        }
    }

@endphp





</div>

@endsection
