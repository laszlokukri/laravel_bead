@extends('layouts.base')

@section('title', 'Új film')

@section('main-content')
<div class="mx-auto" style="max-width: 50rem">

    <form action="{{ route('newmovie') }}" method="post" enctype="multipart/form-data">
        @csrf
        <div class="m-3">
            <label for="cim" class="form-label">A film címe</label>
            <input type="text" value="{{ old('cim') }}" name="cim" id="cim" class="form-control @error('cim') is-invalid @enderror">
            @error('cim')
                <div class="alert alert-danger">A cím megadása kötelező, maximum 255 karakter lehet.</div>
            @enderror
        </div>
        <div class="m-3">
            <label for="rendezo" class="form-label">Rendező</label>
            <input type="text" value="{{ old('rendezo') }}" name="rendezo" id="rendezo" class="form-control @error('rendezo') is-invalid @enderror">
            @error('rendezo')
                <div class="alert alert-danger">Rendező megadása kötelező, maximum 128 karakter lehet</div>
            @enderror
        </div>
        <div class="m-3">
            <label for="ev" class="form-label">Megjelenés éve</label>
            <input type="text" value="{{ old('ev') }}" name="ev" id="ev" class="form-control @error('ev') is-invalid @enderror">
            @error('ev')
                <div class="alert alert-danger">Év megadása kötelező. Legalább 1870, legfeljebb a jelenlegi év.</div>
            @enderror
        </div>
        <div class="m-3">
            <label for="leiras" class="form-label">Leírás</label>
            <textarea name="leiras" id="leiras" class="form-control @error('leiras') is-invalid @enderror" rows="3">{{ old('leiras') }}</textarea>
            @error('leiras')
                <div class="alert alert-danger">A leírás maximum 512 karakter lehet</div>
            @enderror
        </div>
        <div class="m-3">
            <label for="hossz" class="form-label">Hossz</label>
            <input type="text" value="{{ old('hossz') }}" name="hossz" id="hossz" class="form-control @error('hossz') is-invalid @enderror">
            @error('hossz')
                <div class="alert alert-danger">A hossz megadása kötelező</div>
            @enderror
        </div>
        <div class="m-3">
            <label for="kep" class="form-label">Kép feltöltése</label>
            <input type="file" id="kep" class="form-control @error('kep') is-invalid @enderror" name="kep">
            @error('kep')
                <div class="alert alert-danger">A kép formátuma csak jpg és png lehet (maximum 2MB)</div>
            @enderror
        </div>
        <input type="submit" class="btn btn-primary m-3" value="Film beküldése">
    </form>


</div>
@endsection
