<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use App\Models\Rating;
use Illuminate\Http\Request;

class ToplistController extends Controller
{
    public function toplist()
    {
        $movies = Movie::withTrashed()->get();
        $ratings = Rating::all();
        $rts = array(0 => 0);
        $i=0;

        foreach($movies as $movie){
            $i+=1;
            $fn = 0;
            $rts[$i] = 0;
            foreach($ratings as $rating){
                if($movie->id == $rating->movie_id){
                    $rts[$i] = $rts[$i] + $rating->rating;
                    $fn += 1;
                }
            }
            if($fn > 0){
                $rts[$i] = $rts[$i]/$fn;
            }else{
                $rts[$i] = 0;
            }
        }

        return view('toplist', compact('rts','movies'));
    }
}
