<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use App\Models\Rating;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index()
    {
        if(Auth::user() != null){
            if(Auth::user()->is_admin == 1){
                $movies = Movie::withTrashed()->paginate(10);
            }else{
                $movies = Movie::paginate(10);
            }
        }else{
            $movies = Movie::paginate(10);
        }
        $ratings = Rating::all();
        return view('home', compact('movies', 'ratings'));
    }
}
