<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use App\Models\Rating;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class MovieController extends Controller
{
    public function movie(Request $request)
    {
        $id = $request->input('id');
        $movies = Movie::withTrashed()->get();
        $ratings = Rating::all();
        $users = User::all();

        return view('movie', compact('id','movies','ratings','users'));
    }

    public function addRating(Request $request){
        $rating = new Rating;
        $rating->rating = $request->rating;
        $rating->comment = $request->comment;
        $rating->movie_id = $request->movie_id;
        $rating->user_id = Auth::id();
        $rating->save();

        $tmp = 'movie?id=' . $request->movie_id;
        return redirect($tmp);
    }

    public function newMovie(){
        return view('newmovie');
    }

    public function addNewMovie(Request $request){
        $yr = now()->year;
        $validated = $request->validate([
            'cim' => 'required|max:255',
            'rendezo' => 'required|max:128',
            'ev' => 'required|integer|min:1870|max:'. $yr,
            'hossz' => 'required|integer',
            'leiras' => 'max:512',
            'kep' => 'nullable|mimes:jpg,png|max:2000'
        ]);

        $movie = new Movie;

        if($request->kep != null){
            $imageName = time().'.'.$request->kep->getClientOriginalExtension();
            $request->kep->move(public_path('/posters'), $imageName);
            $movie->image = $imageName;
        }else{
            $movie->image = null;
        }


        $movie->title = $request->cim;
        $movie->director = $request->rendezo;
        $movie->year = $request->ev;
        $movie->length = $request->hossz;
        $movie->description = $request->leiras;

        $movie->save();

        return redirect('/');
    }

    public function modMovie(Request $request){
        $id = $request->input('id');
        $film = Movie::withTrashed()->where('id', $id)->first();
        return view('modmovie', ['film' => $film]);
    }

    public function pModMovie(Request $request){
        $yr = now()->year;
        $validated = $request->validate([
            'cim' => 'required|max:255',
            'rendezo' => 'required|max:128',
            'ev' => 'required|integer|min:1870|max:'. $yr,
            'hossz' => 'required|integer',
            'leiras' => 'max:512',
            'kep' => 'nullable|mimes:jpg,png|max:2000'
        ]);

        $movie = Movie::where('id', $request->film_id)->first();;
        $img = public_path('/posters') .'/'.$movie->image;
        if($request->has('torol')){
            File::delete($img);
        }

        if($request->kep != null){
            File::delete($img);
            $imageName = time().'.'.$request->kep->getClientOriginalExtension();
            $request->kep->move(public_path('/posters'), $imageName);
            $movie->image = $imageName;
        }

        $movie->title = $request->cim;
        $movie->director = $request->rendezo;
        $movie->year = $request->ev;
        $movie->length = $request->hossz;
        $movie->description = $request->leiras;

        $movie->save();

        return redirect('movie?id='. $request->film_id)->with('alert', 'Sikeres módosítás!');
    }

    public function deleteratings($id){
        Rating::where('movie_id', $id)->delete();

        return redirect('movie?id='. $id)->with('alert', 'Értékelések törölve!');
    }

    public function deleteMovie($id){
        Movie::where('id', $id)->delete();

        return redirect('movie?id='. $id)->with('alert', 'A film sikeresen törölve!');
    }

    public function restoreMovie($id){
        Movie::where('id', $id)->restore();

        return redirect('movie?id='. $id)->with('alert', 'A film sikeresen helyreállítva!');
    }

}
