<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\MovieController;
use App\Http\Controllers\ToplistController;
use App\Models\Movie;
use GuzzleHttp\Psr7\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/movie', [MovieController::class, 'movie'])->name('movie');
Route::post('/movie', [MovieController::class, 'addRating'])->name('movie');
Route::get('/movie/newmovie', [MovieController::class, 'newMovie'])->name('newmovie');
Route::post('/movie/newmovie', [MovieController::class, 'addNewMovie'])->name('newmovie');
Route::get('/movie/modmovie', [MovieController::class, 'modMovie'])->name('modmovie');
Route::post('/movie/modmovie', [MovieController::class, 'pModMovie'])->name('modmovie');
Route::get('deleterating/{id}', [MovieController::class, 'deleteratings']);
Route::get('movie/deletemovie/{id}', [MovieController::class, 'deleteMovie']);
Route::get('movie/restoremovie/{id}', [MovieController::class, 'restoreMovie']);

Route::get('/toplist', [ToplistController::class, 'toplist'])->name('toplist');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';
