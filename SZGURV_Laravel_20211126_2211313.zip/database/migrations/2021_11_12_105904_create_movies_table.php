<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMoviesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('movies', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('director');
            $table->text('description')->nullable();
            $table->integer('year');
            $table->integer('length');
            $table->string('image')->nullable();
            $table->boolean('ratings_enabled')->default('true');
            $table->timestamps();
            $table->softDeletes();

        });


        #Schema::table('movies', function (Blueprint $table) {
        #    $table->dropSoftDeletes();
        #});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('movies');
    }
}
