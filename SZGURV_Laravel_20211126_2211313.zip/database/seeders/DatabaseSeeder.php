<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        DB::table('users')->insert([
            'name' => 'admin',
            'email' => 'admin@szerveroldali.hu',
            'password' => Hash::make('password'),
            'is_admin' => true
        ]);
        DB::table('users')->insert([
            'name' => 'User1',
            'email' => 'user1@szerveroldali.hu',
            'password' => Hash::make('password')
        ]);
        DB::table('users')->insert([
            'name' => 'User2',
            'email' => 'user2@szerveroldali.hu',
            'password' => Hash::make('password')
        ]);
        DB::table('users')->insert([
            'name' => 'User3',
            'email' => 'user3@szerveroldali.hu',
            'password' => Hash::make('password')
        ]);

        DB::table('movies')->insert([
            'title' => 'Venom 2.',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2021',
            'length' => '5400',
            'image' => 'kep1.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Dűne',
            'director' => 'Denis Villeneuve',
            'description' => 'Paul Atreidesre (Timothée Chalamet) olyan sors vár, amelyet senki fel nem foghat: sem más, sem ő. A távoli jövőben, a bolygóközi királyságok korában járunk. A királyságok az Arrakis bolygó feletti uralomért harcolnak, de a naprendszereken átívelő cselszövések, háborúk és politikai manőverek közepette van egy ember, aki talán békét hozhat az univerzumnak. De ehhez harcolnia kell. Ellenséges bolygók, fantasztikus tájak, különös lények és emberfölötti teljesítmények története ez. És két évszázados királyi ház, az Atreidesek és a Harkonnenek viszályáé. És egy szerelemé, amelyet egész hadseregek sem tehetnek semmissé. Valószínűleg ez 2020 legnagyobb szabású, legkülönlegesebb, legjobban várt filmje – amelyet jórészt Magyarországon forgattak. A Szárnyas fejvadász 2049, az Érkezés és a Sicario rendezője elképesztő szereplőgárda segítségével, két részben álmodta vászonra a kultikus sci-fi regényt.',
            'year' => '2020',
            'length' => '3600',
            'image' => 'kep2.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Pókember',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2018',
            'length' => '4500',
            'image' => 'kep3.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Halálos Iramban',
            'director' => 'Denis Villeneuve',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2015',
            'length' => '4200',
            'image' => 'kep4.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Vasember',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2010',
            'length' => '3800',
            'image' => 'kep5.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Batman',
            'director' => 'Denis Villeneuve',
            'description' => 'Paul Atreidesre (Timothée Chalamet) olyan sors vár, amelyet senki fel nem foghat: sem más, sem ő. A távoli jövőben, a bolygóközi királyságok korában járunk. A királyságok az Arrakis bolygó feletti uralomért harcolnak, de a naprendszereken átívelő cselszövések, háborúk és politikai manőverek közepette van egy ember, aki talán békét hozhat az univerzumnak. De ehhez harcolnia kell. Ellenséges bolygók, fantasztikus tájak, különös lények és emberfölötti teljesítmények története ez. És két évszázados királyi ház, az Atreidesek és a Harkonnenek viszályáé. És egy szerelemé, amelyet egész hadseregek sem tehetnek semmissé. Valószínűleg ez 2020 legnagyobb szabású, legkülönlegesebb, legjobban várt filmje – amelyet jórészt Magyarországon forgattak. A Szárnyas fejvadász 2049, az Érkezés és a Sicario rendezője elképesztő szereplőgárda segítségével, két részben álmodta vászonra a kultikus sci-fi regényt.',
            'year' => '2014',
            'length' => '3900',
            'image' => 'kep6.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Idő',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2021',
            'length' => '3400',
            'image' => 'kep7.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Kampókéz',
            'director' => 'Denis Villeneuve',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2015',
            'length' => '4200',
            'image' => 'kep8.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'A bűnös',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2021',
            'length' => '4800',
            'image' => 'kep9.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Örökkévalók',
            'director' => 'Denis Villeneuve',
            'description' => 'Paul Atreidesre (Timothée Chalamet) olyan sors vár, amelyet senki fel nem foghat: sem más, sem ő. A távoli jövőben, a bolygóközi királyságok korában járunk. A királyságok az Arrakis bolygó feletti uralomért harcolnak, de a naprendszereken átívelő cselszövések, háborúk és politikai manőverek közepette van egy ember, aki talán békét hozhat az univerzumnak. De ehhez harcolnia kell. Ellenséges bolygók, fantasztikus tájak, különös lények és emberfölötti teljesítmények története ez. És két évszázados királyi ház, az Atreidesek és a Harkonnenek viszályáé. És egy szerelemé, amelyet egész hadseregek sem tehetnek semmissé. Valószínűleg ez 2020 legnagyobb szabású, legkülönlegesebb, legjobban várt filmje – amelyet jórészt Magyarországon forgattak. A Szárnyas fejvadász 2049, az Érkezés és a Sicario rendezője elképesztő szereplőgárda segítségével, két részben álmodta vászonra a kultikus sci-fi regényt.',
            'year' => '2013',
            'length' => '3800',
            'image' => 'kep10.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Az utazás',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2018',
            'length' => '4300',
            'image' => 'kep11.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Tom és Jerry',
            'director' => 'Denis Villeneuve',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2019',
            'length' => '3400',
            'image' => 'kep12.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Croodék',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2017',
            'length' => '4000',
            'image' => 'kep13.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Vaksötét',
            'director' => 'Denis Villeneuve',
            'description' => 'Paul Atreidesre (Timothée Chalamet) olyan sors vár, amelyet senki fel nem foghat: sem más, sem ő. A távoli jövőben, a bolygóközi királyságok korában járunk. A királyságok az Arrakis bolygó feletti uralomért harcolnak, de a naprendszereken átívelő cselszövések, háborúk és politikai manőverek közepette van egy ember, aki talán békét hozhat az univerzumnak. De ehhez harcolnia kell. Ellenséges bolygók, fantasztikus tájak, különös lények és emberfölötti teljesítmények története ez. És két évszázados királyi ház, az Atreidesek és a Harkonnenek viszályáé. És egy szerelemé, amelyet egész hadseregek sem tehetnek semmissé. Valószínűleg ez 2020 legnagyobb szabású, legkülönlegesebb, legjobban várt filmje – amelyet jórészt Magyarországon forgattak. A Szárnyas fejvadász 2049, az Érkezés és a Sicario rendezője elképesztő szereplőgárda segítségével, két részben álmodta vászonra a kultikus sci-fi regényt.',
            'year' => '2018',
            'length' => '3700',
            'image' => 'kep14.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'A platform',
            'director' => 'Andy Serkis',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2020',
            'length' => '4200',
            'image' => 'kep15.jpg'
        ]);
        DB::table('movies')->insert([
            'title' => 'Hang nélkül',
            'director' => 'Denis Villeneuve',
            'description' => '„Ha egyszer kiszabadulok innen, lesz egy kis vérontás” – mondta egy titokzatos fegyenc a Venom végén Eddie Brock-nak (Tom Hardy). Annak a vakmerő, nagyszájú tényfeltáró újságírónak, aki egy laboratóriumi felderítése során súlyosan megfertőződött: és azóta szimbiótaként, a testében élősködő gonosz Venommal együtt kénytelen élni. És kezdi megszeretni, hogy egy szupererős szörny lapul benne. Rá is szorul: mert mostantól nemcsak magával kell szembenéznie, hanem egy nála is erősebb, gonoszabb lénnyel, akit nem akar senki rövid pórázon tartani. Jön Vérontó (Woody Harrelson), hogy ígérete szerint pusztítson a világon. Meg kell állítani. Bármi áron....',
            'year' => '2018',
            'length' => '3900',
            'image' => 'kep16.jpg'
        ]);

        DB::table('ratings')->insert([
            'user_id' => '2',
            'movie_id' => '1',
            'rating' => '4',
            'comment' => 'jó film',
            'created_at' => date("Y-m-d H:i:s")
        ]);
        DB::table('ratings')->insert([
            'user_id' => '3',
            'movie_id' => '2',
            'rating' => '5',
            'comment' => 'nem rossz',
            'created_at' => date("Y-m-d H:i:s")
        ]);
    }
}
